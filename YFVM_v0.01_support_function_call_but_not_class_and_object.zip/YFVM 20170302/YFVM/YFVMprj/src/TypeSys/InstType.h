/*
 * RType.h
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#ifndef SRC_TYPESYS_INSTTYPE_H_
#define SRC_TYPESYS_INSTTYPE_H_

#include "InstVar.h"

class InstType: public InstVar {
public:
	InstType();
	virtual ~InstType();
};

#endif /* SRC_TYPESYS_INSTTYPE_H_ */
