/*
 * RFunc.h
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#ifndef SRC_TYPESYS_INSTFUNC_H_
#define SRC_TYPESYS_INSTFUNC_H_
#include "InstVar.h"
class InstFunc: public InstVar {
public:
	InstFunc();
	virtual ~InstFunc();
};

#endif /* SRC_TYPESYS_INSTFUNC_H_ */
