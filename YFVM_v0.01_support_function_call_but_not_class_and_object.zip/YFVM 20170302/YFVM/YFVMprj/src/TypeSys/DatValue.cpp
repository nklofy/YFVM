/*
 * RValue.cpp
 *
 *  Created on: Feb 7, 2017
 *      Author: luyunfei
 */
/*
#include "DatValue.h"

DatValue::DatValue() {
	// TODO Auto-generated constructor stub

}

DatValue::~DatValue() {
	// TODO Auto-generated destructor stub
}*/

