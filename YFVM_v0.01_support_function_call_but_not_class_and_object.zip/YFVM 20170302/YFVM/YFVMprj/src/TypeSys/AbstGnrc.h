/*
 * TGnrc.h
 *
 *  Created on: Jan 23, 2017
 *      Author: luyunfei
 */

#ifndef SRC_TYPESYS_ABSTGNRC_H_
#define SRC_TYPESYS_ABSTGNRC_H_

#include "AbstType.h"

class AbstGnrc : public AbstType {
public:
	AbstGnrc();
	virtual ~AbstGnrc();
};

#endif /* SRC_TYPESYS_ABSTGNRC_H_ */
