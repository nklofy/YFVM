/*
 * RObj.cpp
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#include "InstObj.h"

InstObj::InstObj() {
	// TODO Auto-generated constructor stub

}

InstObj::~InstObj() {
	// TODO Auto-generated destructor stub
}
