/*
 * RGnrc.cpp
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#include "InstGnrc.h"

InstGnrc::InstGnrc() {
	// TODO Auto-generated constructor stub

}

InstGnrc::~InstGnrc() {
	// TODO Auto-generated destructor stub
}

