/*
 * TBasic.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: luyunfei
 */

#include "AbstBasic.h"

AbstBasic::AbstBasic() {
	// TODO Auto-generated constructor stub

}

AbstBasic::~AbstBasic() {
	// TODO Auto-generated destructor stub
}

