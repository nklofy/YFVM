/*
 * RArray.cpp
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#include "InstArray.h"

InstArray::InstArray() {
	// TODO Auto-generated constructor stub

}

InstArray::~InstArray() {
	// TODO Auto-generated destructor stub
}
/*
int InstArray::getArraySize() const {
	return array_size;
}

void InstArray::setArraySize(int arraySize) {
	array_size = arraySize;
}*/
