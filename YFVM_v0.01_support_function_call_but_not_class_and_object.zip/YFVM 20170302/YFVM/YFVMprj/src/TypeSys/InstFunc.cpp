/*
 * RFunc.cpp
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#include "InstFunc.h"

InstFunc::InstFunc() {
	// TODO Auto-generated constructor stub

}

InstFunc::~InstFunc() {
	// TODO Auto-generated destructor stub
}

