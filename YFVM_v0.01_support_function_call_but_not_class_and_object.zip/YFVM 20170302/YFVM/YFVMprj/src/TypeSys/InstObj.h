/*
 * RObj.h
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#ifndef SRC_TYPESYS_INSTOBJ_H_
#define SRC_TYPESYS_INSTOBJ_H_

#include "InstVar.h"

//object in heap
class InstObj: public InstVar {
public:
	InstObj();
	virtual ~InstObj();

private:


};



#endif /* SRC_TYPESYS_INSTOBJ_H_ */
