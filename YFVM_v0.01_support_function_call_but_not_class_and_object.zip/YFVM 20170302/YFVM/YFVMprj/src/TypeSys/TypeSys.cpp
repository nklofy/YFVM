/*
 * TypeSys.cpp
 *
 *  Created on: Jan 12, 2017
 *      Author: luy57690
 */

#include "TypeSys.h"

TypeSys::TypeSys() {
	// TODO Auto-generated constructor stub

}

TypeSys::~TypeSys() {
	// TODO Auto-generated destructor stub
}

