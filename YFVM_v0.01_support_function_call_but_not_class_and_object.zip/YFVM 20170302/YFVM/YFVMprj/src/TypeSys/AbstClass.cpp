/*
 * TClass.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: luyunfei
 */

#include "AbstClass.h"

AbstClass::AbstClass() {
	// TODO Auto-generated constructor stub

}

AbstClass::~AbstClass() {
	// TODO Auto-generated destructor stub
}
