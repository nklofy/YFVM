/*
 * TArray.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: luyunfei
 */

#include "AbstArray.h"

AbstArray::AbstArray() {
	// TODO Auto-generated constructor stub

}

AbstArray::~AbstArray() {
	// TODO Auto-generated destructor stub
}

