/*
 * RType.cpp
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#include "InstType.h"

InstType::InstType() {
	// TODO Auto-generated constructor stub

}

InstType::~InstType() {
	// TODO Auto-generated destructor stub
}

