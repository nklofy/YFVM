/*
 * RGnrc.h
 *
 *  Created on: Feb 1, 2017
 *      Author: luyunfei
 */

#ifndef SRC_TYPESYS_INSTGNRC_H_
#define SRC_TYPESYS_INSTGNRC_H_

#include "InstVar.h"

class InstGnrc: public InstVar {
public:
	InstGnrc();
	virtual ~InstGnrc();
};

#endif /* SRC_TYPESYS_INSTGNRC_H_ */
