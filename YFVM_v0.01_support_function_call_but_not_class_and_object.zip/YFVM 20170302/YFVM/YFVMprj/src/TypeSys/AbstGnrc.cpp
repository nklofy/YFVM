/*
 * TGnrc.cpp
 *
 *  Created on: Jan 23, 2017
 *      Author: luyunfei
 */

#include "AbstGnrc.h"

AbstGnrc::AbstGnrc() {
	// TODO Auto-generated constructor stub

}

AbstGnrc::~AbstGnrc() {
	// TODO Auto-generated destructor stub
}

