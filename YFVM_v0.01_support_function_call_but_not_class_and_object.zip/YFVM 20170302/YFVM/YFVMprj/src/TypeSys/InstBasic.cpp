/*
 * RObjInst.cpp
 *
 *  Created on: Feb 4, 2017
 *      Author: luyunfei
 */

#include "InstBasic.h"

InstBasic::InstBasic() {
	// TODO Auto-generated constructor stub

}

InstBasic::~InstBasic() {
	// TODO Auto-generated destructor stub
}

