/*
 * IR.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: luyunfei
 */

#include "../Loader/IR.h"

IR::IR() {
	// TODO Auto-generated constructor stub

}

IR::~IR() {
	// TODO Auto-generated destructor stub
}

