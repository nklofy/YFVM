/*
 * IR.h
 *
 *  Created on: Jan 20, 2017
 *      Author: luyunfei
 */

#ifndef SRC_LOADER_IR_H_
#define SRC_LOADER_IR_H_

#include "IRCode.h"
#include "RcdFunc.h"

class IR {
public:
	IR();
	virtual ~IR();
};

#endif /* SRC_LOADER_IR_H_ */
