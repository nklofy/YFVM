/*
 * PckgManager.h
 *
 *  Created on: Nov 17, 2016
 *      Author: luyunfei
 */

#ifndef SRC_PCKGMANAGER_H_
#define SRC_PCKGMANAGER_H_

class PckgManager {
public:
	PckgManager();
	virtual ~PckgManager();
};

#endif /* SRC_PCKGMANAGER_H_ */
