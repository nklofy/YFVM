/*
 * GC.cpp
 *
 *  Created on: Nov 17, 2016
 *      Author: luyunfei
 */

#include "GC.h"

GC::GC() {
	// TODO Auto-generated constructor stub

}

GC::~GC() {
	// TODO Auto-generated destructor stub
}

