/*
 * Memory.cpp
 *
 *  Created on: Nov 19, 2016
 *      Author: luyunfei
 */

#include "Memory.h"

Memory::Memory() {
	// TODO Auto-generated constructor stub

}

Memory::~Memory() {
	// TODO Auto-generated destructor stub
}
