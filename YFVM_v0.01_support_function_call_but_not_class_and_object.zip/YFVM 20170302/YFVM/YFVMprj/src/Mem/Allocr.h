/*
 * Allocr.h
 *
 *  Created on: Nov 19, 2016
 *      Author: luyunfei
 */

#ifndef SRC_MEM_ALLOCR_H_
#define SRC_MEM_ALLOCR_H_

class Allocr {
public:
	Allocr();
	virtual ~Allocr();
};

#endif /* SRC_MEM_ALLOCR_H_ */
