/*
 * Allocr.cpp
 *
 *  Created on: Nov 19, 2016
 *      Author: luyunfei
 */

#include "Allocr.h"

Allocr::Allocr() {
	// TODO Auto-generated constructor stub

}

Allocr::~Allocr() {
	// TODO Auto-generated destructor stub
}

