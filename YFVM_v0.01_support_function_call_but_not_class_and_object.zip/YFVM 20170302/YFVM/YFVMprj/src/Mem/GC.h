/*
 * GC.h
 *
 *  Created on: Nov 17, 2016
 *      Author: luyunfei
 */

#ifndef SRC_GC_H_
#define SRC_GC_H_

class GC {
public:
	GC();
	virtual ~GC();
};

#endif /* SRC_GC_H_ */
