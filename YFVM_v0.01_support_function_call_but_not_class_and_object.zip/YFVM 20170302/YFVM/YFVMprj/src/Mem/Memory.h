/*
 * Memory.h
 *
 *  Created on: Nov 19, 2016
 *      Author: luyunfei
 */

#ifndef SRC_MEM_MEMORY_H_
#define SRC_MEM_MEMORY_H_

#include "MemHeap.h"
#include "MemStack.h"

class Memory {
public:
	Memory();
	virtual ~Memory();


private:

};

#endif /* SRC_MEM_MEMORY_H_ */
