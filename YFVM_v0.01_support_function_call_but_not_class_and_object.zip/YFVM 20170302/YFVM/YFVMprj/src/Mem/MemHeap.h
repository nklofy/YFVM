/*
 * MemHeap.h
 *
 *  Created on: Feb 12, 2017
 *      Author: luyunfei
 */

#ifndef SRC_MEM_MEMHEAP_H_
#define SRC_MEM_MEMHEAP_H_

class MemHeap {
public:
	MemHeap();
	virtual ~MemHeap();
};

#endif /* SRC_MEM_MEMHEAP_H_ */
