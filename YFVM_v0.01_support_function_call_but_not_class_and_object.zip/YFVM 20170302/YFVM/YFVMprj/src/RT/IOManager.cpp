/*
 * IOManager.cpp
 *
 *  Created on: Feb 7, 2017
 *      Author: luyunfei
 */

#include "IOManager.h"

IOManager::IOManager() {
	// TODO Auto-generated constructor stub

}

IOManager::~IOManager() {
	// TODO Auto-generated destructor stub
}

