/*
 * IOManager.h
 *
 *  Created on: Feb 7, 2017
 *      Author: luyunfei
 */

#ifndef SRC_IO_IOMANAGER_H_
#define SRC_IO_IOMANAGER_H_

#include "../IO/Input.h"
#include "../IO/Output.h"
class IOManager {
public:
	IOManager();
	virtual ~IOManager();
};

#endif /* SRC_IO_IOMANAGER_H_ */
