/*
 * Output.cpp
 *
 *  Created on: Nov 18, 2016
 *      Author: luyunfei
 */

#include "Output.h"

Output::Output() {
	// TODO Auto-generated constructor stub

}

Output::~Output() {
	// TODO Auto-generated destructor stub
}

