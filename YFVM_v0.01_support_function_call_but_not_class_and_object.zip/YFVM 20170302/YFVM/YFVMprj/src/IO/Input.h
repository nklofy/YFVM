/*
 * Input.h
 *
 *  Created on: Nov 18, 2016
 *      Author: luyunfei
 */

#ifndef SRC_UI_INPUT_H_
#define SRC_UI_INPUT_H_

class Input {
public:
	Input();
	virtual ~Input();
};

#endif /* SRC_UI_INPUT_H_ */
