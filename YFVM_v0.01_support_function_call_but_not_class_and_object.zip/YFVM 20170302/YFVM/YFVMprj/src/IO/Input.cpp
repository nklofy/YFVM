/*
 * Input.cpp
 *
 *  Created on: Nov 18, 2016
 *      Author: luyunfei
 */

#include "Input.h"

Input::Input() {
	// TODO Auto-generated constructor stub

}

Input::~Input() {
	// TODO Auto-generated destructor stub
}

