/*
 * Output.h
 *
 *  Created on: Nov 18, 2016
 *      Author: luyunfei
 */

#ifndef SRC_UI_OUTPUT_H_
#define SRC_UI_OUTPUT_H_

class Output {
public:
	Output();
	virtual ~Output();
};

#endif /* SRC_UI_OUTPUT_H_ */
