# YFVM
YFVM is the virtual machine for YF programming language (YFlang). 
YFVM can load and interpret ".yfc" files which are compiled from ".yfl" files. 

